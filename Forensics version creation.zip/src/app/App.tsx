import { useState } from "react";
import { ForensicsMindMap } from "./components/mind-map";

type HlColor = "green" | "blue" | "red" | "yellow" | "purple" | "orange";

function Hl({ color, children }: { color: HlColor; children: React.ReactNode }) {
  const styles: Record<HlColor, string> = {
    green: "text-[#3fb950] bg-[#3fb95015] px-1 rounded",
    blue: "text-[#58a6ff] bg-[#58a6ff15] px-1 rounded",
    red: "text-[#f85149] bg-[#f8514915] px-1 rounded",
    yellow: "text-[#e3b341] bg-[#e3b34115] px-1 rounded",
    purple: "text-[#d2a8ff] bg-[#d2a8ff15] px-1 rounded",
    orange: "text-[#ffa657] bg-[#ffa65715] px-1 rounded",
  };
  return <span className={styles[color]}>{children}</span>;
}

function CodeBlock({ children }: { children: string }) {
  return (
    <pre className="bg-[#0d1117] border border-[#30363d] rounded-md px-4 py-3 text-[#e6edf3] text-sm overflow-x-auto my-2" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
      <code>{children.trim()}</code>
    </pre>
  );
}

function Note({ title, children }: { title?: string; children: React.ReactNode }) {
  return (
    <div className="border border-[#30363d] bg-[#161b22] rounded-md px-4 py-3 my-3">
      {title && <div className="text-[#3fb950] text-sm mb-1" style={{ fontFamily: "'JetBrains Mono', monospace" }}>▶ {title}</div>}
      <div className="text-[#c9d1d9] text-sm leading-relaxed">{children}</div>
    </div>
  );
}

function SectionHeading({ id, number, children }: { id: string; number: string; children: React.ReactNode }) {
  return (
    <h2 id={id} className="flex items-center gap-3 mt-10 mb-4 pb-2 border-b border-[#30363d]">
      <span className="text-[#3fb950] text-xs px-2 py-0.5 border border-[#3fb950] rounded" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{number}</span>
      <span className="text-[#e6edf3]">{children}</span>
    </h2>
  );
}

function SubHeading({ children }: { children: React.ReactNode }) {
  return (
    <h3 className="text-[#58a6ff] mt-6 mb-2 flex items-center gap-2">
      <span className="text-[#30363d]">##</span>
      {children}
    </h3>
  );
}

function TOCItem({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <li>
      <a href={href} className="text-[#8b949e] hover:text-[#58a6ff] transition-colors text-sm">
        {children}
      </a>
    </li>
  );
}

function FormatCard({ magic, ext, color, children }: { magic: string; ext: string; color: string; children: React.ReactNode }) {
  return (
    <div className="border border-[#30363d] rounded-md overflow-hidden mb-4">
      <div className="flex items-center gap-3 px-4 py-2 bg-[#21262d] border-b border-[#30363d]">
        <span className="text-xs px-2 py-0.5 rounded border" style={{ color, borderColor: color, fontFamily: "'JetBrains Mono', monospace" }}>{ext}</span>
        <span className="text-[#8b949e] text-xs" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{magic}</span>
      </div>
      <div className="px-4 py-3 text-[#c9d1d9] text-sm leading-relaxed">{children}</div>
    </div>
  );
}

const tocSections = [
  { id: "intro", label: "フォレンジックとは" },
  { id: "env", label: "環境構築" },
  { id: "memory", label: "メモリフォレンジック" },
  { id: "file", label: "ファイルフォレンジック" },
  { id: "formats", label: "ファイルフォーマット詳解" },
  { id: "disk", label: "ディスクフォレンジック" },
  { id: "network", label: "ネットワークフォレンジック" },
  { id: "physical", label: "物理ドライブ" },
  { id: "tools", label: "ツール一覧" },
];

export default function App() {
  const [tocOpen, setTocOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground" style={{ fontFamily: "'Noto Sans JP', sans-serif" }}>
      {/* Header */}
      <div className="border-b border-[#30363d] bg-[#161b22] sticky top-0 z-10 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-[#3fb950]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>$ forensics</span>
          <span className="text-[#8b949e] text-sm hidden sm:inline">— CTF Forensics ロードマップ</span>
        </div>
        <button
          onClick={() => setTocOpen(!tocOpen)}
          className="text-[#8b949e] hover:text-[#e6edf3] text-sm transition-colors border border-[#30363d] px-3 py-1 rounded"
        >
          目次
        </button>
      </div>

      {/* TOC Dropdown */}
      {tocOpen && (
        <div className="border-b border-[#30363d] bg-[#161b22] px-6 py-4">
          <ul className="grid grid-cols-2 sm:grid-cols-3 gap-y-1 gap-x-4">
            {tocSections.map((s) => (
              <TOCItem key={s.id} href={`#${s.id}`}>{s.label}</TOCItem>
            ))}
          </ul>
        </div>
      )}

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
        {/* Title */}
        <div className="mb-10">
          <div className="text-[#3fb950] text-xs mb-2" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
            Forensics / CTF 管理ロードマップ
          </div>
          <h1 className="text-[#e6edf3] mb-3">Forensics CTF ロードマップ</h1>
          <p className="text-[#8b949e] text-sm leading-relaxed">
            デジタルフォレンジックの主要分野（メモリ・ファイル・ディスク・ネットワーク）をCTF視点で体系化したロードマップ。
            各分野の基礎知識からツール・実践テクニックまでをまとめています。
          </p>
        </div>

        {/* Mind Map */}
        <div className="mb-10 p-4 border border-[#30363d] rounded-lg bg-[#161b22]">
          <ForensicsMindMap />
        </div>

        {/* ─── 1. フォレンジックとは ─── */}
        <SectionHeading id="intro" number="01">フォレンジックとは</SectionHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-3">
          <Hl color="blue">デジタルフォレンジック</Hl>とは、デジタルデバイスやネットワーク上の証拠を収集・保全・分析・報告する手法・学問分野です。
          元は法廷での証拠調査（コンピュータ犯罪捜査）に由来しますが、CTFでは「隠された情報を掘り出す」問題カテゴリとして広く扱われています。
        </p>
        <p className="text-[#c9d1d9] leading-relaxed mb-3">
          CTFのForensicsカテゴリでは、<Hl color="green">メモリダンプ</Hl>・<Hl color="green">ディスクイメージ</Hl>・
          <Hl color="green">pcapファイル</Hl>・<Hl color="green">特殊なファイル形式</Hl>が問題として与えられ、
          その中に埋め込まれたフラグや隠し情報を見つけることが目的です。
        </p>
        <Note title="CTFでよく出るジャンル">
          <ul className="list-none space-y-1">
            <li><Hl color="green">メモリフォレンジック</Hl> — RAM ダンプから情報を抽出する</li>
            <li><Hl color="blue">ファイルフォレンジック</Hl> — 隠しデータ・ステガノグラフィ・ファイルカービング</li>
            <li><Hl color="orange">ディスクフォレンジック</Hl> — ディスクイメージのパーティション・削除ファイル復元</li>
            <li><Hl color="purple">ネットワークフォレンジック</Hl> — pcap 解析・プロトコル復元</li>
          </ul>
        </Note>

        {/* ─── 2. 環境構築 ─── */}
        <SectionHeading id="env" number="02">環境構築</SectionHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-3">
          Forensics問題を解く環境として、<Hl color="green">Kali Linux</Hl> または <Hl color="green">Ubuntu</Hl> を推奨します。
          多くのツールがプリインストールされており、Dockerでも手軽に環境を用意できます。
        </p>
        <SubHeading>必須ツールのインストール</SubHeading>
        <CodeBlock>{`# Volatility3 (メモリフォレンジック)
pip install volatility3

# binwalk (ファイル埋め込み解析)
sudo apt install binwalk

# Wireshark / tshark (パケット解析)
sudo apt install wireshark tshark

# foremost / scalpel (ファイルカービング)
sudo apt install foremost

# steghide (ステガノグラフィ)
sudo apt install steghide

# Autopsy (GUIディスク解析)
sudo apt install autopsy

# exiftool (メタデータ抽出)
sudo apt install libimage-exiftool-perl

# hexdump / xxd (バイナリ確認)
sudo apt install xxd`}</CodeBlock>
        <Note>
          Docker を使う場合は <Hl color="green">remnux/remnux-distro</Hl> イメージが便利です。
          REMnux はマルウェア解析・フォレンジック向けのLinuxディストリビューションで、主要ツールが一通り揃っています。
        </Note>

        {/* ─── 3. メモリフォレンジック ─── */}
        <SectionHeading id="memory" number="03">メモリフォレンジック</SectionHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-3">
          <Hl color="blue">メモリフォレンジック</Hl>はコンピュータのRAMダンプを解析し、実行中プロセス・ネットワーク接続・
          パスワード・暗号鍵・コマンド履歴などを抽出する手法です。CTFでは <Hl color="red">.raw</Hl>・<Hl color="red">.mem</Hl>・
          <Hl color="red">.dmp</Hl>・<Hl color="red">.vmem</Hl> などの拡張子でダンプファイルが渡されます。
        </p>

        <SubHeading>Volatility — 基本コマンド</SubHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-2">
          <Hl color="green">Volatility</Hl> はメモリフォレンジックのデファクトスタンダードツールです。
          Volatility 2 と Volatility 3 が存在しますが、現在は <Hl color="green">Volatility 3</Hl> が主流です。
        </p>
        <CodeBlock>{`# OSプロファイルの特定 (Volatility 3)
python3 vol.py -f memory.raw windows.info

# 実行中プロセス一覧
python3 vol.py -f memory.raw windows.pslist

# プロセスツリー表示（親子関係）
python3 vol.py -f memory.raw windows.pstree

# ネットワーク接続一覧
python3 vol.py -f memory.raw windows.netstat

# コマンド履歴の抽出
python3 vol.py -f memory.raw windows.cmdline

# レジストリキーの列挙
python3 vol.py -f memory.raw windows.registry.hivelist

# プロセスのメモリをダンプ
python3 vol.py -f memory.raw windows.memdump --pid 1234

# ファイル一覧
python3 vol.py -f memory.raw windows.filescan`}</CodeBlock>

        <SubHeading>重要なアーティファクト</SubHeading>
        <Note title="よく調査する情報">
          <ul className="list-none space-y-1.5">
            <li><Hl color="green">プロセス (pslist/pstree)</Hl> — 不審なプロセス名、異常な親子関係を確認</li>
            <li><Hl color="blue">ネットワーク接続 (netstat)</Hl> — C&amp;Cサーバーへの接続、異常なポート</li>
            <li><Hl color="orange">コマンドライン (cmdline)</Hl> — 実行されたコマンド、引数にフラグが含まれる場合あり</li>
            <li><Hl color="purple">レジストリ (hivelist)</Hl> — 自動実行、認証情報、各種設定</li>
            <li><Hl color="red">ファイルスキャン (filescan)</Hl> — メモリにマップされたファイルの探索</li>
          </ul>
        </Note>

        <SubHeading>Linuxメモリの解析</SubHeading>
        <CodeBlock>{`# Linuxプロセス一覧
python3 vol.py -f linux.raw linux.pslist

# Bashコマンド履歴
python3 vol.py -f linux.raw linux.bash

# ソケット一覧
python3 vol.py -f linux.raw linux.sockstat`}</CodeBlock>

        {/* ─── 4. ファイルフォレンジック ─── */}
        <SectionHeading id="file" number="04">ファイルフォレンジック</SectionHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-3">
          <Hl color="blue">ファイルフォレンジック</Hl>は、ファイルの内部構造・メタデータ・隠し情報を調査する分野です。
          CTFでは<Hl color="green">ステガノグラフィ</Hl>（データの隠蔽技術）、<Hl color="green">ファイルカービング</Hl>（埋め込みファイルの抽出）、
          <Hl color="green">マジックバイト解析</Hl>が頻出します。
        </p>

        <SubHeading>マジックバイト（ファイルシグネチャ）</SubHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-2">
          ファイルの先頭数バイトには<Hl color="blue">マジックバイト</Hl>と呼ばれる識別子があります。
          拡張子が偽装されていても、マジックバイトで真のファイル形式を判定できます。
        </p>
        <CodeBlock>{`# ファイルタイプ判定
file suspicious_file

# バイナリ先頭を16進数で確認
xxd suspicious_file | head -5
hexdump -C suspicious_file | head -10`}</CodeBlock>

        <SubHeading>ステガノグラフィ</SubHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-3">
          <Hl color="blue">ステガノグラフィ</Hl>は画像・音声・テキストなどにデータを秘匿する技術です。
          暗号化とは異なり、データの存在自体を隠蔽します。
        </p>
        <Note title="主な手法">
          <ul className="list-none space-y-1.5">
            <li><Hl color="green">LSB (Least Significant Bit)</Hl> — 画像の各ピクセルの最下位ビットにデータを埋め込む。視覚的変化は最小限</li>
            <li><Hl color="blue">ファイル末尾への追記</Hl> — JPEG等では画像データ終端 (FF D9) 以降に任意データを追記可能</li>
            <li><Hl color="orange">チャンクへの埋め込み</Hl> — PNG の補助チャンク、EXIF メタデータへの格納</li>
            <li><Hl color="purple">音声ステガノ</Hl> — スペクトログラムに文字が描かれているパターン、位相符号化</li>
          </ul>
        </Note>
        <CodeBlock>{`# steghide でパスワード付き抽出 (JPEG/BMP対応)
steghide extract -sf image.jpg -p ""

# zsteg (PNG/BMP の LSB 解析)
zsteg image.png
zsteg -a image.png  # 全チャネル試行

# stegsolve (GUIツール - 各ビットプレーン表示)
java -jar stegsolve.jar

# strings で埋め込みテキストを探す
strings image.png | grep -i flag

# exiftool でメタデータ抽出
exiftool image.jpg

# binwalk で埋め込みファイル検出・展開
binwalk image.jpg
binwalk -e image.jpg  # 自動展開`}</CodeBlock>

        <SubHeading>ファイルカービング</SubHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-2">
          <Hl color="blue">ファイルカービング</Hl>は、ファイルシステム情報なしにバイナリデータからマジックバイトを手がかりとして
          ファイルを復元する技術です。削除ファイルの復元やダンプからのファイル抽出に使います。
        </p>
        <CodeBlock>{`# foremost でファイルカービング
foremost -i disk.img -o output_dir/

# scalpel (高速なカービングツール)
scalpel disk.img -o output_dir/

# binwalk でもカービング可能
binwalk --dd='.*' suspicious.bin`}</CodeBlock>

        {/* ─── 5. ファイルフォーマット詳解 ─── */}
        <SectionHeading id="formats" number="05">ファイルフォーマット詳解</SectionHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-4">
          CTFでは各ファイル形式の内部構造を理解することで、手動での解析・修復・隠しデータの発見が可能になります。
          以下は頻出ファイル形式のシグネチャと構造の概要です。
        </p>

        <FormatCard ext="ZIP" magic="50 4B 03 04 (PK\x03\x04)" color="#ffa657">
          <p className="mb-2">
            ZIPは<Hl color="orange">Local File Header</Hl>（個々のファイルエントリ）と<Hl color="orange">Central Directory</Hl>（ファイル索引）で構成されます。
            各ローカルヘッダは <Hl color="red">PK\x03\x04</Hl> で始まり、ファイル名・圧縮サイズ・非圧縮サイズを格納。
            Central Directoryは <Hl color="red">PK\x01\x02</Hl> で始まりファイル末尾付近に存在します。
          </p>
          <CodeBlock>{`# パスワード付きZIPの解析
zip2john archive.zip > hash.txt
john hash.txt

# 破損ZIPの修復
zip -FF corrupted.zip --out fixed.zip

# zipdetails で構造確認
zipdetails archive.zip`}</CodeBlock>
        </FormatCard>

        <FormatCard ext="PDF" magic="25 50 44 46 (%PDF-)" color="#58a6ff">
          <p className="mb-2">
            PDFは<Hl color="blue">オブジェクト</Hl>の集合で構成され、各オブジェクトは
            <Hl color="red">obj</Hl> / <Hl color="red">endobj</Hl> で囲まれます。
            ストリームオブジェクト（<Hl color="blue">stream</Hl> / <Hl color="blue">endstream</Hl>）には
            画像・フォント・埋め込みファイルが含まれます。
            <Hl color="orange">xref</Hl>テーブルがオブジェクトオフセットを管理します。
          </p>
          <CodeBlock>{`# PDF内のオブジェクト抽出
pdf-parser.py suspicious.pdf
pdf-parser.py --object 5 --filter suspicious.pdf

# 埋め込みJSの検出
peepdf suspicious.pdf

# strings で平文検索
strings suspicious.pdf | grep -i flag`}</CodeBlock>
        </FormatCard>

        <FormatCard ext="JPG/JPEG" magic="FF D8 FF (先頭) / FF D9 (終端)" color="#3fb950">
          <p className="mb-2">
            JPEGはマーカーベースの形式です。<Hl color="red">FF D8 FF</Hl>で始まり<Hl color="red">FF D9</Hl>で終わります。
            主要なセグメント：<Hl color="blue">APP0/APP1</Hl>（EXIFメタデータ）、
            <Hl color="blue">DQT</Hl>（量子化テーブル）、<Hl color="blue">SOF</Hl>（フレーム開始）、
            <Hl color="blue">DHT</Hl>（ハフマンテーブル）、<Hl color="blue">SOS</Hl>（スキャン開始 = 画像データ本体）。
            <Hl color="orange">FF D9 以降のデータ</Hl>は無視されるためデータ隠蔽によく使われます。
          </p>
          <CodeBlock>{`# EXIFデータ確認
exiftool photo.jpg

# FF D9以降のデータ確認
xxd photo.jpg | grep -A3 "ff d9"

# steghide で抽出 (パスワードなし)
steghide extract -sf photo.jpg -p ""`}</CodeBlock>
        </FormatCard>

        <FormatCard ext="PNG" magic="89 50 4E 47 0D 0A 1A 0A (\x89PNG\r\n\x1a\n)" color="#d2a8ff">
          <p className="mb-2">
            PNGはチャンク構造を持ちます。各チャンクは<Hl color="blue">長さ(4B) + チャンクタイプ(4B) + データ + CRC(4B)</Hl>で構成。
            必須チャンク：<Hl color="green">IHDR</Hl>（画像メタ情報・先頭固定）、
            <Hl color="green">IDAT</Hl>（圧縮された画像データ・複数可）、
            <Hl color="green">IEND</Hl>（終端マーカー）。
            補助チャンク（<Hl color="orange">tEXt, zTXt, iTXt, bKGD</Hl>等）にデータを隠す問題が頻出。
            CRCを改ざんして縦横サイズを偽装するパターンも要注意。
          </p>
          <CodeBlock>{`# PNGチャンク構造の確認
pngcheck -v image.png

# CRC検証・修復
python3 -c "
import struct, zlib
with open('image.png','rb') as f:
    data = f.read()
# IHDRのCRC再計算 (幅・高さ改ざん検出)
ihdr = data[12:29]
print(hex(zlib.crc32(ihdr) & 0xffffffff))
"

# zsteg でLSBステガノ解析
zsteg image.png`}</CodeBlock>
        </FormatCard>

        <FormatCard ext="BMP" magic="42 4D (BM)" color="#f78166">
          <p className="mb-2">
            BMPは<Hl color="blue">ファイルヘッダ(14B)</Hl> + <Hl color="blue">DIBヘッダ(40B以上)</Hl> + <Hl color="orange">ピクセルデータ</Hl>の単純構造です。
            ピクセルデータは非圧縮のBGR(A)形式が基本で、行は4バイト境界にパディングされます。
            LSBステガノグラフィの対象になりやすく、<Hl color="green">steghide</Hl>・<Hl color="green">zsteg</Hl>が有効です。
            画像の幅・高さ・ビット深度を読んでピクセルデータを直接パースする問題もあります。
          </p>
          <CodeBlock>{`# ヘッダ確認 (オフセット0x0A に ピクセルデータ開始オフセット)
xxd image.bmp | head -4

# Python でピクセルデータ読み込み
from PIL import Image
img = Image.open("image.bmp")
pixels = list(img.getdata())  # (R,G,B) のリスト`}</CodeBlock>
        </FormatCard>

        <FormatCard ext="TAR" magic="先頭ブロックの ustar 魔法文字列 (オフセット 0x101)" color="#e3b341">
          <p className="mb-2">
            TARは<Hl color="blue">512バイト固定ブロック</Hl>単位で構成されます。各ファイルエントリは
            <Hl color="blue">ヘッダブロック(512B)</Hl> + <Hl color="blue">データブロック群(512B×n)</Hl>から成ります。
            ヘッダには<Hl color="orange">ファイル名(100B)・パーミッション・UID/GID・サイズ・タイムスタンプ・チェックサム</Hl>が格納。
            <Hl color="red">ustar</Hl> は POSIX 準拠形式の識別子（オフセット 0x101 〜 0x105）。
            アーカイブの終端は512バイトのゼロブロックが2つ連続。
          </p>
          <CodeBlock>{`# 内容確認
tar tvf archive.tar

# 展開
tar xvf archive.tar -C output/

# 隠しファイルやシンボリックリンクの確認
tar tvf archive.tar | grep "^\."
tar tvf archive.tar | grep " -> "`}</CodeBlock>
        </FormatCard>

        <FormatCard ext="WAV" magic="52 49 46 46 (RIFF)" color="#3fb950">
          <p className="mb-2">
            WAVは<Hl color="blue">RIFF</Hl>コンテナ形式を使用します。構造：
            <Hl color="green">RIFF チャンク</Hl>（4B "RIFF" + 4B ファイルサイズ + 4B "WAVE"）→
            <Hl color="green">fmt チャンク</Hl>（サンプリングレート・チャンネル数・ビット深度）→
            <Hl color="green">data チャンク</Hl>（実際のPCMサンプルデータ）。
            ステガノグラフィとして<Hl color="orange">LSBに埋め込み</Hl>・<Hl color="orange">スペクトログラム</Hl>に画像が描かれているパターンが頻出。
            また<Hl color="red">LIST, cue, smpl</Hl>等の補助チャンクにデータが隠れることも。
          </p>
          <CodeBlock>{`# スペクトログラムの可視化 (Audacity or Python)
python3 -c "
import wave, numpy as np, matplotlib.pyplot as plt
w = wave.open('audio.wav')
frames = w.readframes(w.getnframes())
samples = np.frombuffer(frames, dtype=np.int16)
plt.specgram(samples, Fs=w.getframerate(), cmap='inferno')
plt.savefig('spectrogram.png')
"

# WAVのLSBステガノ解析
python3 -c "
with open('audio.wav','rb') as f:
    data = f.read()[44:]  # fmtチャンク後のデータ
bits = ''.join([str(b & 1) for b in data])
text = ''.join([chr(int(bits[i:i+8],2)) for i in range(0,len(bits),8)])
print(text[:200])
"`}</CodeBlock>
        </FormatCard>

        {/* ─── 6. ディスクフォレンジック ─── */}
        <SectionHeading id="disk" number="06">ディスクフォレンジック</SectionHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-3">
          <Hl color="orange">ディスクフォレンジック</Hl>はディスクイメージ（<Hl color="red">.img</Hl>・<Hl color="red">.dd</Hl>・<Hl color="red">.iso</Hl>）を解析し、
          パーティション構造・ファイルシステム・削除ファイルの復元などを行う分野です。
        </p>

        <SubHeading>パーティションテーブル</SubHeading>
        <Note title="MBR (Master Boot Record)">
          <p>
            ディスク先頭の<Hl color="blue">512バイト</Hl>がMBRです。構成：
            ブートストラップコード(446B) + <Hl color="orange">パーティションテーブル(64B)</Hl> + 署名 <Hl color="red">55 AA</Hl>(2B)。
            パーティションテーブルは最大4エントリで、各エントリ16Bに
            スタートLBA・セクタ数・パーティションタイプが格納されます。
          </p>
        </Note>
        <Note title="GPT (GUID Partition Table)">
          <p>
            MBRの制限（2TB・4パーティション）を克服した現代の規格。
            セクタ1に<Hl color="blue">GPTヘッダ</Hl>、セクタ2〜33に<Hl color="blue">パーティションエントリ配列</Hl>。
            末尾にバックアップGPTが存在します。
          </p>
        </Note>
        <CodeBlock>{`# fdisk でパーティション確認
fdisk -l disk.img

# パーティション情報
mmls disk.img

# 特定パーティションをマウント
sudo mount -o loop,offset=$((2048*512)) disk.img /mnt/part/

# testdisk でパーティション復元
testdisk disk.img`}</CodeBlock>

        <SubHeading>ファイルシステム</SubHeading>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-3">
          {[
            { name: "FAT32", color: "#ffa657", desc: "Windows/USBメモリ。クラスタチェーン管理。削除時はFAT上の先頭エントリを0xE5に書き換えるのみ→復元しやすい" },
            { name: "NTFS", color: "#58a6ff", desc: "Windows標準。MFT(Master File Table)でファイルを管理。$MFT, $LogFile, $UsnJrnl が重要なアーティファクト" },
            { name: "ext4", color: "#3fb950", desc: "Linux標準。iノードベース。削除時にiノードのデータブロック参照をクリア→残データが残ることも" },
          ].map((fs) => (
            <div key={fs.name} className="border border-[#30363d] rounded p-3 bg-[#161b22]">
              <div className="mb-1" style={{ color: fs.color, fontFamily: "'JetBrains Mono', monospace" }}>{fs.name}</div>
              <p className="text-[#8b949e] text-xs leading-relaxed">{fs.desc}</p>
            </div>
          ))}
        </div>
        <CodeBlock>{`# ファイルシステム解析 (Autopsy)
autopsy  # GUI起動 → ブラウザでlocalhost:9999

# fls でファイル一覧 (削除ファイルは * 付き)
fls -r disk.img

# icat でiノードから内容抽出
icat disk.img 14  # iノード番号14のファイルを出力

# 削除ファイルの復元
photorec disk.img`}</CodeBlock>

        {/* ─── 7. ネットワークフォレンジック ─── */}
        <SectionHeading id="network" number="07">ネットワークフォレンジック</SectionHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-3">
          <Hl color="purple">ネットワークフォレンジック</Hl>はパケットキャプチャファイル（<Hl color="red">.pcap</Hl>・<Hl color="red">.pcapng</Hl>）を
          解析してネットワーク上の通信を復元・調査する分野です。
        </p>

        <SubHeading>Wireshark の基本</SubHeading>
        <CodeBlock>{`# フィルタ例
http                      # HTTPのみ
dns                       # DNSのみ
tcp.port == 21            # FTP制御チャネル
frame contains "flag"     # ペイロードに"flag"を含むパケット
ip.addr == 192.168.1.1    # 特定IPとの通信
http.request.method == "POST"  # POSTリクエスト

# tshark (CLIでの解析)
tshark -r capture.pcap -Y "http" -T fields -e http.request.uri
tshark -r capture.pcap -Y "dns" -T fields -e dns.qry.name

# Follow TCP Stream でセッション再構成 (Wireshark GUI)
# 右クリック → Follow → TCP Stream`}</CodeBlock>

        <SubHeading>よくあるプロトコルの調査ポイント</SubHeading>
        <Note>
          <ul className="list-none space-y-2">
            <li><Hl color="purple">HTTP</Hl> — GET/POSTのURLとパラメータ、Cookie、Basic認証のBase64デコード</li>
            <li><Hl color="blue">FTP</Hl> — ポート21(制御)とデータ転送(ポート20かPASVで動的割り当て)に分割。認証情報が平文で流れる</li>
            <li><Hl color="green">DNS</Hl> — クエリ名にBase64等でエンコードしたデータを乗せる「DNSトンネリング」が頻出</li>
            <li><Hl color="orange">SMTP/POP3</Hl> — メール本文・添付ファイルがBase64エンコードで流れる。手動デコードで抽出可能</li>
            <li><Hl color="red">ICMP</Hl> — pingのペイロードにデータを隠す手法がある</li>
          </ul>
        </Note>
        <CodeBlock>{`# pcap からファイル自動抽出 (NetworkMiner or tshark)
tshark -r capture.pcap --export-objects http,./http_files/
tshark -r capture.pcap --export-objects ftp-data,./ftp_files/

# DNSクエリ名を全て抽出してデコード
tshark -r capture.pcap -Y "dns.flags.response==0" \\
  -T fields -e dns.qry.name | base64 -d 2>/dev/null`}</CodeBlock>

        {/* ─── 8. 物理ドライブ ─── */}
        <SectionHeading id="physical" number="08">物理ドライブの基礎知識</SectionHeading>
        <p className="text-[#c9d1d9] leading-relaxed mb-3">
          物理ドライブ（HDD・SSD・USBメモリ等）はフォレンジックにおける証拠媒体として最も重要な対象です。
          ドライブ全体の構造を理解することが、正確な解析の基礎となります。
        </p>

        <SubHeading>基本単位</SubHeading>
        <div className="border border-[#30363d] rounded-md overflow-hidden mb-4">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[#21262d] border-b border-[#30363d]">
                <th className="text-left px-4 py-2 text-[#8b949e]">単位</th>
                <th className="text-left px-4 py-2 text-[#8b949e]">サイズ</th>
                <th className="text-left px-4 py-2 text-[#8b949e]">説明</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["セクタ", "512B または 4096B (4K)", "ディスクの最小読み書き単位。物理的な単位"],
                ["クラスタ", "セクタ×N（FS依存）", "ファイルシステムの割り当て単位。通常4KB〜64KB"],
                ["シリンダ/ヘッド/セクタ (CHS)", "物理ジオメトリ", "古い参照方式。現在はLBA(論理ブロックアドレス)が主流"],
                ["LBA", "0番地から連番", "ディスク全体を連番のセクタ番地で管理するアドレッシング方式"],
              ].map(([unit, size, desc], i) => (
                <tr key={i} className="border-b border-[#30363d] last:border-0">
                  <td className="px-4 py-2 text-[#3fb950]" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{unit}</td>
                  <td className="px-4 py-2 text-[#e3b341] text-xs">{size}</td>
                  <td className="px-4 py-2 text-[#8b949e]">{desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <SubHeading>ディスクイメージの取得</SubHeading>
        <CodeBlock>{`# dd でビット単位のイメージ取得 (証拠保全)
sudo dd if=/dev/sdb of=disk.img bs=4M status=progress

# ハッシュ値で完全性を確認
md5sum disk.img > disk.img.md5
sha256sum disk.img > disk.img.sha256

# dcfldd (dd の拡張版 - 取得中にハッシュ計算)
dcfldd if=/dev/sdb of=disk.img hash=sha256 hashlog=hash.txt

# 読み取り専用マウント (元データを保護)
sudo mount -o ro,noexec /dev/sdb1 /mnt/evidence/`}</CodeBlock>

        <Note title="ライトブロッカー (Write Blocker)">
          フォレンジック調査では証拠媒体への書き込みを防ぐ<Hl color="blue">ライトブロッカー</Hl>を使用します。
          ソフトウェア的には <Hl color="green">blockdev --setro</Hl> や
          <Hl color="green">mount -o ro</Hl> でも代替可能ですが、
          物理的なハードウェアライトブロッカーが法的証拠として好まれます。
        </Note>

        {/* ─── 9. ツール一覧 ─── */}
        <SectionHeading id="tools" number="09">CTFで使うツール一覧</SectionHeading>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            {
              category: "メモリ解析",
              color: "#3fb950",
              tools: [
                ["Volatility 3", "メモリダンプ解析のデファクトスタンダード"],
                ["strings", "バイナリから印字可能文字を抽出"],
                ["bulk_extractor", "メモリ/ディスクから各種情報を自動抽出"],
              ],
            },
            {
              category: "ファイル解析",
              color: "#58a6ff",
              tools: [
                ["binwalk", "ファイルに埋め込まれたデータを検出・展開"],
                ["file", "マジックバイトによるファイルタイプ判定"],
                ["exiftool", "画像・ドキュメントのメタデータ抽出"],
                ["foremost / scalpel", "ファイルカービングツール"],
              ],
            },
            {
              category: "ステガノグラフィ",
              color: "#d2a8ff",
              tools: [
                ["steghide", "JPEG/BMPのステガノ隠蔽・抽出"],
                ["zsteg", "PNG/BMPのLSBステガノ解析"],
                ["stegsolve", "ビットプレーン可視化GUIツール"],
                ["Stegseek", "steghide の高速ブルートフォース"],
              ],
            },
            {
              category: "ディスク解析",
              color: "#f78166",
              tools: [
                ["Autopsy", "GUIフォレンジックツール"],
                ["testdisk / photorec", "パーティション復元・ファイルカービング"],
                ["dd / dcfldd", "ディスクイメージ取得"],
                ["sleuthkit (fls, icat)", "CLIファイルシステム解析"],
              ],
            },
            {
              category: "ネットワーク解析",
              color: "#ffa657",
              tools: [
                ["Wireshark", "GUIパケット解析"],
                ["tshark", "CLIパケット解析・フィルタ"],
                ["NetworkMiner", "pcapからファイルを自動抽出"],
                ["tcpdump", "リアルタイムパケットキャプチャ"],
              ],
            },
            {
              category: "ヘキサエディタ / バイナリ",
              color: "#e3b341",
              tools: [
                ["xxd / hexdump", "バイナリの16進表示"],
                ["hexedit", "CLIヘキサエディタ"],
                ["010 Editor", "テンプレート機能付き高機能ヘキサエディタ"],
                ["CyberChef", "Web上で各種エンコード・変換を行うツール"],
              ],
            },
          ].map((section) => (
            <div key={section.category} className="border border-[#30363d] rounded-md overflow-hidden">
              <div className="px-4 py-2 bg-[#21262d] border-b border-[#30363d]" style={{ color: section.color, fontFamily: "'JetBrains Mono', monospace", fontSize: "12px" }}>
                {section.category}
              </div>
              <ul className="divide-y divide-[#30363d]">
                {section.tools.map(([name, desc]) => (
                  <li key={name} className="px-4 py-2 flex gap-3 items-start">
                    <span className="shrink-0 text-[#e6edf3] text-sm" style={{ fontFamily: "'JetBrains Mono', monospace", minWidth: "120px" }}>{name}</span>
                    <span className="text-[#8b949e] text-xs leading-relaxed">{desc}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-16 pt-6 border-t border-[#30363d] text-center text-[#8b949e] text-xs">
          <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>Forensics CTF Roadmap</span>
          <span className="mx-2 text-[#30363d]">|</span>
          <span>メモリ・ファイル・ディスク・ネットワーク フォレンジック 学習ガイド</span>
        </div>
      </div>
    </div>
  );
}
