export function ForensicsMindMap() {
  const W = 900;
  const rootCX = 450;

  const categories = [
    { cx: 120, label1: "メモリ", label2: "フォレンジック", color: "#3fb950", toolLabel: "Volatility" },
    { cx: 340, label1: "ファイル", label2: "フォレンジック", color: "#58a6ff", toolLabel: "binwalk / steghide" },
    { cx: 560, label1: "ディスク", label2: "フォレンジック", color: "#f78166", toolLabel: "Autopsy / dd" },
    { cx: 780, label1: "ネットワーク", label2: "フォレンジック", color: "#d2a8ff", toolLabel: "Wireshark" },
  ];

  const branchY = 80;
  const catTopY = 92;
  const catH = 54;
  const catBottomY = catTopY + catH;
  const subTopY = catBottomY + 16;
  const subH = 28;
  const catW = 155;
  const subW = 130;

  return (
    <svg
      viewBox={`0 0 ${W} ${subTopY + subH + 12}`}
      width="100%"
      style={{ fontFamily: "'JetBrains Mono', 'Noto Sans JP', monospace" }}
      aria-label="Forensics CTFロードマップ マインドマップ"
    >
      {/* Root box */}
      <rect x={rootCX - 90} y={8} width={180} height={40} rx={5} fill="#161b22" stroke="#3fb950" strokeWidth={1.5} />
      <text x={rootCX} y={33} textAnchor="middle" fill="#3fb950" fontSize={13} fontWeight="600">
        Forensics CTF
      </text>

      {/* Root → branch line */}
      <line x1={rootCX} y1={48} x2={rootCX} y2={branchY} stroke="#30363d" strokeWidth={1} />

      {/* Horizontal branch */}
      <line x1={categories[0].cx} y1={branchY} x2={categories[categories.length - 1].cx} y2={branchY} stroke="#30363d" strokeWidth={1} />

      {categories.map((cat, i) => (
        <g key={i}>
          {/* Branch → category vertical */}
          <line x1={cat.cx} y1={branchY} x2={cat.cx} y2={catTopY} stroke="#30363d" strokeWidth={1} />

          {/* Category box */}
          <rect x={cat.cx - catW / 2} y={catTopY} width={catW} height={catH} rx={4} fill="#161b22" stroke={cat.color} strokeWidth={1.5} />
          <text x={cat.cx} y={catTopY + 20} textAnchor="middle" fill={cat.color} fontSize={12} fontWeight="500">
            {cat.label1}
          </text>
          <text x={cat.cx} y={catTopY + 37} textAnchor="middle" fill={cat.color} fontSize={12} fontWeight="500">
            {cat.label2}
          </text>

          {/* Category → sub vertical */}
          <line x1={cat.cx} y1={catBottomY} x2={cat.cx} y2={subTopY} stroke="#30363d" strokeWidth={1} />

          {/* Sub-node box */}
          <rect x={cat.cx - subW / 2} y={subTopY} width={subW} height={subH} rx={3} fill="#0d1117" stroke="#30363d" strokeWidth={1} />
          <text x={cat.cx} y={subTopY + 18} textAnchor="middle" fill="#8b949e" fontSize={10} fontWeight="400">
            {cat.toolLabel}
          </text>
        </g>
      ))}
    </svg>
  );
}
