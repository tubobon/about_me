
  # Forensics version creation

  This is a code bundle for Forensics version creation. The original project is available at https://www.figma.com/design/OsxU8SDeJ3wVFp376RLe8C/Forensics-version-creation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  